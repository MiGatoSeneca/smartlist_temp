#!/usr/bin/env bash

CURRENT_DIR=`pwd`
PLUGIN_NAME="converfitlist"
ZIP_NAME="prestashop_${@:1}_${PLUGIN_NAME}.zip"
FILES_TO_ERASE=".idea .git .gitignore deploy converfitlist.iml
                config/*.json smartlist/config/*.json smartlist/config/ai/*.json smartlist/var/*.json"


rm -f *.zip
TMPDIR=`mktemp -d` # Crea directorio temporal
rsync -av . $TMPDIR/${PLUGIN_NAME} # Copia el directorio
cd $TMPDIR/${PLUGIN_NAME}
# Borramos los archivos de configuración y los relacionados con desarrollo

rm -Rf ${FILES_TO_ERASE}
zip -r ${ZIP_NAME} ../${PLUGIN_NAME}
cd -
mv $TMPDIR/${PLUGIN_NAME}/${ZIP_NAME} ${CURRENT_DIR}
