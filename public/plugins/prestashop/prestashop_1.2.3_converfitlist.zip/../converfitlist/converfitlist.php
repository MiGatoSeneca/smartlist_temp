<?php
if(!defined('_PS_VERSION_'))
    exit;

class ConverfitList extends Module{

    private $defaultConfigFile = array(
        "ordersOverride" => ["","position"],
        "debug" => "none"
    );

    private $debug = "";
    private $ordersOverride = "";
    private $gaActive = false;

    private function writeLog($str){
        if($this->debug == "local"){
            error_log("[".$this->smartlist->getApiKey()."] ".$str);
        }else if($this->debug == "server"){
            $this->smartlist->sendLog($str);
        }
    }

    public function __construct(){

        $this->name = 'converfitlist';
        $this->tab = 'advertising_marketing';
        $this->version = '1.2.3';
        $this->author ='Converfit Team';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Converfit - Smart List');
        $this->description = $this->l('Converfir - Smart List Module to order product by user preferences.');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

        require realpath(dirname(__FILE__))."/smartlist/smartlist.php";
        $this->smartlist = new SmartList("Prestashop", $this);

        $this->initConfigFile();

        $pathname = realpath(dirname(__FILE__))."/config/config.json";
        $config = json_decode(file_get_contents($pathname),true);

        if(isset($config["ordersOverride"])){
            $this->ordersOverride = $config["ordersOverride"];
        }else{
            $this->ordersOverride = array();
        }

        if(isset($config["debug"])){
            $this->debug = $config["debug"];
        }else{
            $this->debug = "";
        }
    }

    public function getContent(){
        $return = $this->process_form();
        $return .= $this->display_form();
        return $return;
    }

    protected function process_form(){
        $html="";
        $this->writeLog("process_form");
        $this->writeLog(json_encode($_POST));

        if(isset($_POST['apiKey'])){
            $formRes = true;
            $formErrors = array();

            if(isset($_POST['apiKey']) && $_POST['apiKey']!=""){
                $this->smartlist->setApiKey($_POST['apiKey']);
            }else{
                $formErrors[] = "Es necesario introducir un apiKey.";
            }

            if(isset($_POST['eventsLimit']) && $_POST['eventsLimit']!=""){
                $this->smartlist->setEventsLimit($_POST['eventsLimit']);
            }else{
                $formErrors[] = "Es necesario introducir el número de eventos que la IA procesará.";
            }

            $ordersOverride = array();
            if(isset($_POST['ordersOverride']) && $_POST['ordersOverride'] != ""){
                $ordersOverride = explode(",",$_POST['ordersOverride']);
            }
            if(isset($_POST['emptyOverride'])){
                $ordersOverride[] = '';
            }
            if(isset($_POST['positionOverride'])){
                $ordersOverride[] = 'position';
            }
            $this->ordersOverride = $ordersOverride;
            $this->setConfigValue("ordersOverride",$ordersOverride);

            if(isset($_POST['gaActive'])){
                $this->smartlist->setGaActive(true);
            }else{
                $this->smartlist->setGaActive(false);
            }

            if(isset($_POST['debugPrestashop']) && $_POST['debugPrestashop']!=""){
                $this->debug = $_POST['debugPrestashop'];
                $this->setConfigValue("debug",$_POST['debugPrestashop']);
            }else{
                $formErrors[] = "Es necesario selecciona un valor para el Modo de Depuración del Módulo de Prestashop.";
            }

            if(isset($_POST['debugModule']) && $_POST['debugModule']!=""){
                $this->smartlist->setDebug($_POST['debugModule']);
            }else{
                $formErrors[] = "Es necesario selecciona un valor para el Modo de Depuración del Módulo.";
            }


            if(sizeOf($formErrors)==0){
                $html .= '
          <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <p><strong>¡Éxito!</strong> Se han almacenado los datos correctamente</p>
          </div>
        ';
            }

            if(sizeOf($formErrors)>0){
                $html .= '
          <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <p><b>¡Error!</b> No se ha podido almacenar los cambios</p>
            <br/>
            <p><b>Listado de errores:</b></p>
            <ul id="infos_block" class="list-unstyled">
            ';
                foreach($formErrors as $key => $formError){
                    $html .= '
              <li>'.$formError.'</li>
              ';
                }
                $html .= '
            </ul>
          </div>
        ';
            }

        }
        return $html;
    }

    private function display_form(){
        $html="";

        $orderOverrideValue = "";
        $coma = "";
        $emptyOverrideSelected = "";
        $positionOverrideSelected = "";

        if(isset($this->ordersOverride) && is_Array($this->ordersOverride)){
            foreach($this->ordersOverride as $key => $orderOverride){
                if($orderOverride == ""){
                    $emptyOverrideSelected = "checked";
                }else if($orderOverride == "position"){
                    $positionOverrideSelected = "checked";
                }else{
                    $orderOverrideValue .= $coma.$orderOverride;
                    $coma = ",";
                }
            }

        }
        $gaActiveSelected = '';
        if($this->smartlist->getGaActive()){
            $gaActiveSelected = 'checked';
        }


        $debugPrestashopSelected["server"] = '';
        $debugPrestashopSelected["local"] = '';
        $debugPrestashopSelected["none"] = '';
        if(isset($debugPrestashopSelected[$this->debug])){
            $debugPrestashopSelected[$this->debug] = 'selected';
        }


        $debugModuleSelected["server"] = '';
        $debugModuleSelected["local"] = '';
        $debugModuleSelected["none"] = '';
        if(isset($debugModuleSelected[$this->smartlist->getDebug()])){
            $debugModuleSelected[$this->smartlist->getDebug()] = 'selected';
        }
        $log = "";
        $log .= $this->checkHooks();

        $html = '
    <div class="panel">
      <div class="panel-heading">
        <div class="row">
          <div class="col-md-6">
            Configurar Conver.fit - Smart List
          </div>
          <div class="col-md-6 text-right">
            <span class="small text-muted">Version: '.$this->version.'</span>
          </div>
        </div>
      </div>
      <div class="panel-body">
        <table class="table">
          <tr>
            <td>
              <p class="h3">Converfit - SmartList</p>
            </td>
            <td class="text-right">
            <a href="https://smartlist.conver.fit" class="btn btn-primary" target="_blank">Accede al Dashboard</a>
            </td>
          </tr>
        </table>
        <br/>
        <form method="post">
          <div class="row">
            <div class="col-md-6">
              <p><b>Configuración General</b></p>
              <hr/>
              <div class="form-group">
                <label for="apiKey">Clave de la API (ApiKey)</label>
                <input type="text" class="form-control" id="apiKey" name="apiKey" value="'.$this->smartlist->getApiKey().'">
                <small id="apiKey" class="form-text">La clave de API es necesaria para conectar con nuestro servidor de entrenamiento, podrá localizarla en nuestro dashboard.</small>
              </div>
              <div class="form-group">
                <label for="eventsLimit">Número de eventos a considerar para personalizar</label>
                <p><small class="form-text text-danger"><b>Atención:</b> Los eventos son almacenados en la cookie, un número elevado puede generar errores de Cookie 502, en caso de que esto pase descienda el número de eventos a considerar.</small></p>
                <input type="number" class="form-control" id="eventsLimit" name="eventsLimit" value="'.$this->smartlist->getEventsLimit().'">
                <small id="eventsLimit" class="form-text">Para personalizar se tendrán en cuenta las X últimas acciones, cuanto mayor sea el número más precisa será la decisión pero menos adaptable a cambios, recomendado: [5 - 15]</small>
              </div>
            </div>
            <div class="col-md-6">
              <p><b>Configuración Modulo Prestashop</b></p>
              <hr/>
              <div class="form-group">
                <label>¿Cuando usar la ordenación Smart·List?</label>
                <p>Smart·List funcionará por defecto cuando el listado de los productos sea vacío o se seleccione el orden por posición de productos, si quieres desactivar temporalmente Smart·List sólo tendrás que desmarcar las opciones que tienes a continuación.</p>
                <label>Ordenaciones de producto por defecto:</label>
                <div class="checkbox">
                  <label><input type="checkbox" name="positionOverride" '.$positionOverrideSelected.'>Usar Smart·List cuando el <b>orden es por posición</b></label>
                </div>
                <div class="checkbox">
                  <label><input type="checkbox" name="emptyOverride" '.$emptyOverrideSelected.'>Usar Smart·List cuando el <b>orden no está definido</b></label>
                </div>
                <label>Ampliar las ordenaciones de productos que usa Smart·List</label>
                <input type="text" class="form-control" id="ordersOverride" name="ordersOverride" placeholder=\'Utiliza el identificador del orden y sepáralo por comas Ej.: price,reference  \' value="'.$orderOverrideValue.'">
                <small class="form-text">Escribe aquí separado por comas los identificadores de las ordenaciones de prouductos que quieres utilizar.</small>
              </div>
            </div>
          </div>
          <p><b>Status</b></p>
          <pre>'.$log.'</pre>
          <br/>
          <p><b>Sincronización con Servidor de entrenamiento de AI</b> <a data-toggle="collapse" data-target="#syncAIOptions" href="#">(mostrar/ocultar)</a></p>
          <hr/>
          <div id="syncAIOptions" class="collapse">
            <p>Para el funcionamiento correcto de este módulo es necesario sincronizar su AI local con la versión entrenada que se encuentra en nuestros servidores, para ello es necesario que configure una <b>tarea cron</b> que permita recibir las actualizaciones</p>
            <p><b>Instrucciones</b></p>
            <p><b>1.-</b> Acceda a su módulo de tareas cron, buscándolo en módulos o utilizando el buscador de su backoffice.</p>
            <p><b>2.-</b> Pulse el botón añadir que encontrará en la tabla de tareas en la esquina derecha.</p>
            <p><b>3.-</b> Rellene el formulario con los siguientes datos.</p>
                <table class="table">
                  <thead>
                    <tr>
                      <th class="text-right" style="width:1px;white-space: nowrap;"><b>Campo</b></th>
                      <th><b>Valor</b></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td class="text-right" style="width:1px;white-space: nowrap;"><b>Descripción de la tarea</b></td>
                      <td>Smartlist Update</td>
                    </tr>
                    <tr>
                      <td class="text-right" style="width:1px;white-space: nowrap;"><b>Objetivo del enlace</b></td>
                      <td>'._PS_BASE_URL_._MODULE_DIR_.'converfitlist/tools/cron.php?apiKey='.$this->smartlist->getApiKey().'</td>
                    </tr>
                  </tbody>
                </table>
                <br/>

            <p><b>4.-</b> Seleccione la frecuencia en la que desea que los datos se actualicen. (Preferible mente 1 vez a día)</p>
            <p><b>5.-</b> Pulse el botón Guardar.</p>

          </div>
          <br/>
          <p><b>Seguimiento Google Analytics</b> <a data-toggle="collapse" data-target="#googleAnalyticsOptions" href="#">(mostrar/ocultar)</a></p>
          <hr/>
          <div id="googleAnalyticsOptions" class="collapse">
            <p>Para hacer el seguimiento en Google Analytics, marca la opción que encontrarás a continuzación. Dentro de tu panel de Analytics aparecerá un nuevo tipo de eventos que podrás usar para filtrar a tu audiencia.</p>
            <p>Descripción del evento:<p>
            <ul>
              <li><b>Categoría del Evento</b>: <i>Converfit</i></li>
              <li><b>Acción del Evento</b>: <i>Smartlist</i></li>
              <li><b>Etiqueta del Evento</b>: <i>[smartlist_yes|smartlist_no]</i></li>
            </ul>
            <p>Crea dentro de Analytics un segmento para usuarios que tengan un evento con <i>etiqueta = smartlist_yes</i> y otro con <i>etiqueta = smartlist_yes</i>. Gracias a estos dos segmentos podrás ver de forma sencilla cual es la diferencia entre los dos segmentos.</p>
            <div class="form-group">
              <div class="checkbox">
                <label><input type="checkbox" name="gaActive" '.$gaActiveSelected.'>Activar seguimiento con <b>Google Analytics</b></label>
              </div>
            </div>
          </div>
          <br/>
          <p><b>Opciones de Depuración</b> <a data-toggle="collapse" data-target="#advancedOptions" href="#">(mostrar/ocultar)</a></p>
          <hr/>
          <div id="advancedOptions" class="collapse">
            <div class="form-group">
              <label for="debugPrestashop">Modo de Depuración - Módulo Prestashop</label>
              <select class="form-control" id="debugPrestashop" name="debugPrestashop">
                <option value="server" '.$debugPrestashopSelected["server"].'>Servidor</option>
                <option value="local" '.$debugPrestashopSelected["local"].'>Local</option>
                <option value="none" '.$debugPrestashopSelected["none"].'>Desactivado</option>
              </select>
              <small class="form-text">El modo de depuración permite tanto localmente como remotamente comprobar el estado del sistema</small>
            </div>
            <div class="form-group">
              <label for="debugModule">Modo de Depuración - Módulo</label>
              <select class="form-control" id="debugModule" name="debugModule">
                <option value="server" '.$debugModuleSelected["server"].'>Servidor</option>
                <option value="local" '.$debugModuleSelected["local"].'>Local</option>
                <option value="none" '.$debugModuleSelected["none"].'>Desactivado</option>
              </select>
              <small class="form-text">El modo de depuración permite tanto localmente como remotamente comprobar el estado del sistema</small>
            </div>
          </div>
          <br/>
          <hr/>
          <div class="row">
            <div class="col-md-6 text-left">
              <a href="http://smartlist.converfit.com" target="_blank">¿No tienes cuenta? Crea una en nuestro dashboard</a>
            </div>
            <div class="col-md-6 text-right">
              <button type="submit" class="btn btn-primary">Guardar cambios</button>
            </div>
          </div>
        </form>
      </div>
    </div>
    ';
        return $html;
    }

    /**
     * initConfigFile
     * Inicializa el fichero de configurtación config/configjson que guarda el
     * apiKey de este módulo.
     *
     * @return  boolean   éxito de la operación
     */

    private function initConfigFile(){

        //Comprueba si existe el fichero config/config.json
        $pathname = realpath(dirname(__FILE__))."/config/config.json";
        if(!file_exists($pathname) || filesize($pathname)==0){
            //Si no existe
            //Almacena defaultConfigFile en config/config.json
            file_put_contents($pathname,json_encode($this->defaultConfigFile),LOCK_EX);
        }
        //Devuelve true
        return true;
    }

    private $_hooks = array(
        'Header',
        'actionProductListModifier',
        'displayProductContent',
        'actionCartSave'
    );

    public function checkHooks(){
        $log = "<br/>";
        $log = "CheckHooks<br/>";
        foreach ($this->_hooks as $hook){
            if($this->registerHook($hook)){
                $log .= "Hook: ".$hook." Register [<b class='text-success'>OK</b>]<br/>";
            }else{
                $log .= "Hook: ".$hook." unregister [<b class='text-danger'>ERROR</b>]<br/>";
            }
        }
        return $log;
    }

    public function install(){
        $this->writeLog("[Install] Start");

        if(!parent::install() || !$this->registerHook('Header')){
            $this->writeLog("[Install] Error registerHook(header)");
            return false;
        }
        if(!parent::install() || !$this->registerHook('actionProductListModifier')){
            $this->writeLog("[Install] Error registerHook(actionProductListModifier)");
            return false;
        }
        if(!parent::install() || !$this->registerHook('displayProductContent')){
            $this->writeLog("[Install] Error registerHook(displayProductContent)");
            return false;
        }
        if(!parent::install() || !$this->registerHook('actionCartSave')){
            $this->writeLog("[Install] Error registerHook(actionCartSave)");
            return false;
        }
        $this->writeLog("[Install] Done");

        return true;
    }

    public function uninstall(){
        $this->writeLog("[Uninstall] Start");

        if(!parent::uninstall() || !$this->unregisterHook('Header')){
            $this->writeLog("[Uninstall] Error unregisterHook(Header)");
            return false;
        }
        if(!parent::uninstall() || !$this->unregisterHook('actionProductListModifier')){
            $this->writeLog("[Uninstall] Error unregisterHook(actionProductListModifier)");
            return false;
        }
        if(!parent::uninstall() || !$this->unregisterHook('displayProductContent')){
            $this->writeLog("[Uninstall] Error unregisterHook(displayProductContent)");
            return false;
        }
        if(!parent::uninstall() || !$this->unregisterHook('actionCartSave')){
            $this->writeLog("[Uninstall] Error unregisterHook(actionCartSave)");
            return false;
        }

        $this->writeLog("[Uninstall] Done");
        return true;
    }

    public function hookHeader(){
        $html = "";

        if($this->smartlist->getGaActive()){
            $html .= "<script>";
            $html .= $this->smartlist->getGaScript();
            $html .= "</script>";
        }

        return $html;
    }

    public function hookactionCartSave($productData){


        $this->writeLog("[hookactionCartSave] Start");

        if(!(!$this->context->cart || !Tools::getValue('id_product') || !Tools::getValue('add') || !Tools::getValue('ajax'))) {
            $product = new Product((int)Tools::getValue('id_product'));
            if(Validate::isLoadedObject($product)){
                $productSkeletor = $this->getProductSkeletor($product);
                $this->smartlist->createEvent("add",$productSkeletor);
            }
        }
    }

    public function getProductSkeletor($product){
        $this->writeLog("[getProductSkeletor] Start");


        if(!is_Array($product)){
            $arrayProduct = (array)$product;
        }else{
            $arrayProduct = $product;
        }

        if(!isset($arrayProduct["id"])){

            $arrayProduct["id"] = $arrayProduct["id_product"];
        }

        if(is_Array($product)){
            $product = new Product($arrayProduct["id"]);
        }

        $productSkeletor = array(
            "IID" => $arrayProduct["reference"],
            "properties" => array()
        );

        $properties = array("id","id_manufacturer","id_category_default","on_sale","price","new");

        foreach ($properties as $key => $property){
            if(isset($arrayProduct[$property])){
                $this->writeLog("[getProductSkeletor] [".$productSkeletor["IID"]."] ".$property." = ".$arrayProduct[$property]);
                $productSkeletor["properties"][$property] = $arrayProduct[$property];
            }else{
                $this->writeLog("[getProductSkeletor] [".$productSkeletor["IID"]."] ".$property." doesn't exisit");
            }
        }

        if(@isset($arrayProduct["attributes"])){
            $this->writeLog("[getProductSkeletor] [".$productSkeletor["IID"]."] Extract direct attributes");

            $tmpVector = explode(",",$arrayProduct["attributes"]);
            foreach ($tmpVector as $key =>$tmpPair){
                $tmp = explode(" : ",$tmpPair);
                $productSkeletor["properties"][$tmp[0]]=$tmp[1];
            }
        }else{

            $combinations = $product->getAttributeCombinations((int)$this->context->language->id);
            if(@isset($combinations) && (sizeOf($combinations)>0)){
                $this->writeLog("[getProductSkeletor] [".$productSkeletor["IID"]."] Extract attributes from combinations");

                foreach ($combinations as $key => $combination){
                    $this->writeLog("[getProductSkeletor] [".$productSkeletor["IID"]."] Start attribute_".$combination["group_name"]);

                    $group_name = $combination["group_name"];
                    $attribute_name = $combination["attribute_name"];
                    if(!isset($productSkeletor["properties"]["attribute_".$group_name])){
                        $productSkeletor["properties"]["attribute_".$group_name] = $attribute_name;
                    }else{
                        if(!is_array($productSkeletor["properties"]["attribute_".$group_name])){
                            $old_attribute_name = $productSkeletor["properties"]["attribute_".$group_name];
                            if($old_attribute_name!=$attribute_name){
                                $productSkeletor["properties"]["attribute_".$group_name]=[$old_attribute_name,$attribute_name];
                            }
                        }else{
                            if(!in_array($attribute_name,$productSkeletor["properties"]["attribute_".$group_name])){
                                $productSkeletor["properties"]["attribute_".$group_name][]=$attribute_name;
                            }
                        }
                    }
                    $this->writeLog("[getProductSkeletor] [".$productSkeletor["IID"]."] attribute_".$group_name." = ".json_encode($productSkeletor["properties"]["attribute_".$group_name]));
                }
            }else{
                $this->writeLog("[getProductSkeletor] [".$productSkeletor["IID"]."] Don't have attributes");
            }

        }


        $features = Product::getFrontFeaturesStatic((int)$this->context->language->id,(int)$arrayProduct["id"]);
        if(@isset($features)){
            foreach($features as $key => $feature){
                $this->writeLog("[getProductSkeletor] [".$productSkeletor["IID"]."] attribute_".$feature["name"]." = ".$feature["value"]);

                $productSkeletor["properties"]["attribute_".$feature["name"]]=$feature["value"];
            }
        }else{
            $this->writeLog("[getProductSkeletor] [".$productSkeletor["IID"]."] Don't have properties");
        }
        $this->writeLog("[getProductSkeletor] Done");

        return $productSkeletor;
    }

    public function hookdisplayProductContent($productData){

        $this->writeLog("[hookdisplayProductContent] Start");

        $product = $productData["product"];
        $productSkeletor = $this->getProductSkeletor($product);
        $this->smartlist->createEvent("view",$productSkeletor);

        $this->writeLog("[hookdisplayProductContent] Done");

    }

    public function hookactionProductListModifier($productList){
        $this->writeLog("[hookactionProductListModifier] Start");
        $orderBy = Tools::getValue('orderby');
        $this->writeLog("[hookactionProductListModifier] [INFO] orderBy: ".$orderBy);

        $orderOverride = false;
        foreach($this->ordersOverride as $key => $orderType){
            if($orderBy==$orderType){
                $orderOverride = true;
            }
        }

        if($orderOverride){
            $this->writeLog("[hookactionProductListModifier] [INFO] orderOverride: true");

            $item = array(
                "IID" => "none",
                "properties" => array()
            );
            $this->smartlist->createEvent("list",$item);

            foreach($productList["cat_products"] as $key => $value){
                $productList["cat_products"][$key]["sortField"]=$this->getProductSkeletor($productList["cat_products"][$key]);
            }
            $productList["cat_products"] = $this->smartlist->sort($productList["cat_products"]);
        }

        $this->writeLog("[hookactionProductListModifier] Done");

    }

    private function getAttributeAvailableCombinations($id_product){
        $this->writeLog("[getAttributeAvailableCombinations] Start");

        $sql = 'SELECT pa.id_product, pa.id_product_attribute, pa.minimal_quantity, a.id_attribute
        FROM `'._DB_PREFIX_.'product_attribute` pa
        '.Shop::addSqlAssociation('product_attribute', 'pa').'
        LEFT JOIN `'._DB_PREFIX_.'product_attribute_combination` pac ON pac.`id_product_attribute` = pa.`id_product_attribute`
        LEFT JOIN `'._DB_PREFIX_.'attribute` a ON a.`id_attribute` = pac.`id_attribute`
        WHERE pa.`id_product` = '.(int)$id_product.'
        ORDER BY pa.`id_product_attribute`';

        $res = Db::getInstance()->executeS($sql);
        foreach ($res as $key => $row){
            $cache_key = $row['id_product'].'_'.$row['id_product_attribute'].'_quantity';
            if (!Cache::isStored($cache_key)){
                Cache::store(
                    $cache_key,
                    StockAvailable::getQuantityAvailableByProduct($row['id_product'], $row['id_product_attribute'])
                );
            }
            $quantity = Cache::retrieve($cache_key);
            if($quantity<$res[$key]['minimal_quantity']){
                unset($res[$key]);
            }
        }

        $this->writeLog("[getAttributeAvailableCombinations] End");

        return $res;
    }

    private function setConfigValue($key,$value){
        $this->initConfigFile();

        $pathname = realpath(dirname(__FILE__))."/config/config.json";
        $config = json_decode(file_get_contents($pathname),true);
        $config[$key] = $value;
        file_put_contents($pathname,json_encode($config),LOCK_EX);
        return $value;
    }

    public function getCookie() {
        return $this->context->cookie;
    }
}
