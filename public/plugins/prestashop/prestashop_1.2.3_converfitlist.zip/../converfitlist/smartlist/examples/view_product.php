<?php
  require "../smartlist.php";

  $smartlist = new SmartList();

  $product = array(
    "IID" => "HELLOSKU",
    "properties" => array(
      "price" => 120.90,
      "color" => "blue",
      "sizes" => ["32","34"]
    )
  );

  $smartlist->createEvent("view",$product);

?>
