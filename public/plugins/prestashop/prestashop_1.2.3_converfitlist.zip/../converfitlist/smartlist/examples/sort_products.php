<?php
  require "../smartlist.php";

  $smartlist = new SmartList();

  $sizes = array("XS","S","M","L","XL");
  $colors = array("blue","red","black","white","grey");
  $styles = array("tredy","floral","rock","punk","elegant");
  $products = array();

  for($i=0;$i<100;$i++){
    $randSize = rand(0,4);
    $randColor = rand(0,4);
    $randStyle = rand(0,4);
    $randPrice = rand(100,500);
    $product = array(
      "IID" => dechex($i*1024)."-".$i,
      "properties" => array(
        "price" => $randPrice,
        "color" => $colors[$randColor],
        "sizes" => $sizes[$randSize],
        "style" => $styles[$randStyle]
      )
    );
    $products[]=$product;
  }

  for($i=1;$i<=1;$i++){
    $randProduct = rand(0,99);
    $smartlist->createEvent("view",$products[$randProduct]);
  }

  $productsToSort = array();

  for($i=1;$i<=25;$i++){
    $randProduct = rand(0,99);
    $productsToSort[] = $products[$randProduct];
  }
  $productsSorted = $smartlist->sort($productsToSort);


  echo "<p>Original Products</p>";
  echo "<code>";
  foreach($productsToSort as $key=>$value){
    echo $value["IID"]." ";
  }
  echo "</code>";

  echo "<br/>";

  echo "<p>Sorted Products</p>";

  echo "<code>";
  foreach($productsSorted as $key=>$value){
    echo $value["IID"]." ";
  }
  echo "</code>";





?>
