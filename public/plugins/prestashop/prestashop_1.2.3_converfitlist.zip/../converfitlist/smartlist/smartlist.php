<?php

/*
 * Copyright (c) 2017, Converfit. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * All rights reserved. No part of this code may be reproduced,
 * distributed, or transmitted in any form or by any means without
 * the prior written permission of the publisher, except in the
 * case of brief quotations embodied in critical reviews and certain
 * other noncommercial uses permitted by copyright law. For permission
 * requests, write to the publisher, at the address below.
 *
 * Please contact us via email at info@converfit.com
 *
 * www.conver.fit
 *
 * @author Converfit Team
 *
 * @version 1.2.3
 * @last_update 2017/11/10
 *
 */

if (!class_exists('SmartList')) {
    class SmartList {

        private $defaultAppFile = array(
            "version" => "1.2.3",
            "url" => "http://smartlist.conver.fit/api/"
        );

        private $defaultConfigFile = array(
            "apiKey" => "your_apikey",
            "gaActive" => false,
            "eventsLimit" => "5",
            "autoSaveGraph" => true,
            "sortType" => "graphAI",
            "debug" => "none"
        );

        private $defaultABConfig = array(
            "values" => array("y","y","y","y","y","y","y","y","y","n")
        );
        private $defaultABVar = array(
            "position" => 0
        );

        private $defaultAIConfig = array(
            "IID" => "",
            "properties" => array()
        );

        private $url = '';
        private $version = '';
        private $debug = '';

        private $cms = '';
        private $cmsContext;
        private $cmsCookie = '';
        private $cookie = array();

        private $apiKey = '';
        private $eventsLimit = '';
        private $gaActive = false;

        private $classPath = '';
        private $UID = '';
        private $abTest = '';
        private $ai = '';
        private $graphAI = '';

        private $aiPromote = '';
        private $aiDescend = '';
        private $aiSkip = '';

        private $autoSaveGraph = '';
        private $sortType = '';

        private $events = array();

        public function setGaActive($value){
            $this->gaActive = $value;
            return $this->setConfigValue("gaActive",$value);
        }

        public function getGaActive(){
            return $this->gaActive;
        }

        public function getGaScript(){
            $html = "";
            $html .= "$(document).ready(function() {";
            $html .= " if(typeof ga !== 'undefined'){";
            $html .= "   ga('send', 'event', 'Converfit','SmartList','smartlist_".$this->getAbTest()."');";
            $html .= " }";
            $html .= "});";
            return $html;

        }

        public function sendLog($str){
            $data = array(
                "str"=> $str
            );

            $options = array(
                'http' => array(
                    'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
                    'method'  => 'POST',
                    'content' => http_build_query($data),
                    'timeout' => 1
                )
            );
            $context  = stream_context_create($options);
            $result = @file_get_contents($this->url.$this->apiKey."/log", false, $context);

        }

        private function writeLog($str){
            if($this->debug == "local"){
                error_log("[".$this->apiKey."] ".$str);
            }else if($this->debug == "server"){
                $this->sendLog($str);
            }
        }

        public function getABTest(){
            $response = "no";
            if($this->abTest == "y"){
                $response = "yes";
            }
            return $response;
        }

        private function initCookies(){

            if(isset($this->cms) && ($this->cms=="Prestashop")){
                if(file_exists('config/config.inc.php')){
                    include_once('config/config.inc.php');
                }
                if(file_exists('config/settings.inc.php')){
                    include_once('config/settings.inc.php');
                }
                if(file_exists('classes/Cookie.php')){
                    include_once('classes/Cookie.php');
                }
                $this->cmsCookie = new Cookie("Smartlist");
                if(!isset($this->cmsCookie->smartList)){
                    $this->cmsCookie->smartList="{}";
                    $this->cookie = array();
                }else{
                    $this->cookie = json_decode($this->cmsCookie->smartList,true);
                }
            }
        }

        private function getCookie($key){
            if(isset($this->cms) && ($this->cms=="Prestashop")){
                if(isset($this->cookie[$key])){
                    return $this->cookie[$key];
                }else{
                    if ($key == "smartListEvents") {
                        return $this->getPrestashopViewEvents();
                    }
                    return null;
                }
            }else{
                if(isset($_COOKIE[$key])){
                    return $_COOKIE[$key];
                }else{
                    if(isset($this->cookie[$key])){
                        return $this->cookie[$key];
                    }else{
                        return null;
                    }
                }
            }
        }

        /**
         * Función encargada de recoger los eventos de la cookie interna de prestashop
         * siguiendo el formato original
         */
        private function getPrestashopViewEvents() {
            $prestashopCookie = $this->cmsContext->getCookie();
            $itemIDsArray = array_reverse(explode(',', $prestashopCookie->viewed));
            $viewEventsArray = array();
            for ($i = 0; $i < $this->eventsLimit && $i < count($itemIDsArray); $i++) {
                $product = new Product($itemIDsArray[$i]);
                $viewEventsArray[] = array('event'=>"view",'IID'=>$product->reference);
            }
            return json_encode($viewEventsArray);
        }

        public function setCookie($key,$value){
            if (!headers_sent()) {
                if(isset($this->cms) && ($this->cms=="Prestashop")){
                    $this->writeLog("[setCookie] [Prestashop] key = ".$key.", value = ".$value);
                    $this->cookie[$key] = $value;
                    $this->adaptPrestashopCookie($key, $value);
                }else{
                    setcookie($key,$value);
                    $this->cookie[$key] = $value;
                }
            }else{
                $this->cookie[$key] = $value;
            }
        }


        /**
         * Función encargada de guardar en la cookie de PrestaShop solamente los datos necesarios
         */
        private function adaptPrestashopCookie() {
            $cookie = $this->cookie; // Copia del array
            unset($cookie['smartListEvents']); // Elimina el campo smartListEvents por ser innecesario para Prestashop
            $this->writeLog('[adaptPrestashopCookie] Old cookie = '.implode(', ',$this->cookie));
            $this->writeLog('[adaptPrestashopCookie] Prestashop cookie = '.implode(', ', $cookie));
            $this->cmsCookie->smartList=json_encode($cookie);
            $this->cmsCookie->write();
        }

        public function getEventsLimit(){
            return $this->eventsLimit;
        }

        public function setEventsLimit($value){
            $this->eventsLimit = $value;
            return $this->setConfigValue("eventsLimit",$value);
        }

        public function getautoSaveGraph(){
            return $this->autoSaveGraph;
        }

        public function setAutoSaveGraph($value){
            $this->autoSaveGraph = $value;
            return $this->setConfigValue("autoSaveGraph",$value);
        }

        public function getSortType(){
            return $this->sortType;
        }

        public function setSortType($value){
            $this->sortType = $value;
            return $this->setConfigValue("sortType",$value);
        }

        /**
         * getUrl
         * Duelve la url utilizada para conectarse con el servidor de predicción
         *
         * @return string url del servidor de predicción
         */
        public function getDebug(){
            return $this->debug;
        }

        /**
         * setUrl
         * Actualiza la url utilizada para conectarse con el servidor de predicción
         *
         * @return string url del servidor de predicción
         */
        public function setDebug($value){
            $this->debug = $value;
            return $this->setConfigValue("debug",$value);
        }

        /**
         * getUrl
         * Duelve la url utilizada para conectarse con el servidor de predicción
         *
         * @return string url del servidor de predicción
         */
        public function getUrl(){
            return $this->url;
        }

        /**
         * setUrl
         * Actualiza la url utilizada para conectarse con el servidor de predicción
         *
         * @return string url del servidor de predicción
         */
        public function setUrl($value){
            $this->url = $value;
            return $this->setAppValue("url",$value);
        }

        /**
         * getUrl
         * Duelve la url utilizada para conectarse con el servidor de predicción
         *
         * @return string url del servidor de predicción
         */
        public function getVersion(){
            return $this->version;
        }

        /**
         * setUrl
         * Actualiza la url utilizada para conectarse con el servidor de predicción
         *
         * @return string url del servidor de predicción
         */
        private function setVersion($value){
            $this->version = $value;
            return $this->setAppValue("version",$value);
        }

        /**
         * getApiKey
         * Devuelve el apiKey utilizado actualmente
         *
         * @return string llave de acceso al API del servidor
         */
        public function getApiKey(){
            return $this->apiKey;
        }

        /**
         * setApiKey
         * Actualiza el apiKey utilizado
         * config/config.json
         *
         * @param string $apiKey Nueva llave a almacenar
         */
        public function setApiKey($value){
            $this->apiKey = $value;
            return $this->setConfigValue("apiKey",$value);
        }

        private function setConfigValue($key,$value){
            $this->initConfigFile();

            $pathname = realpath(dirname(__FILE__))."/config/config.json";
            $config = json_decode(file_get_contents($pathname),true);
            $config[$key] = $value;
            file_put_contents($pathname,json_encode($config),LOCK_EX);
            return $value;

        }

        private function setAppValue($key,$value){
            $this->initConfigFile();

            $pathname = realpath(dirname(__FILE__))."/config/app.json";
            $app = json_decode(file_get_contents($pathname),true);
            $app[$key] = $value;
            file_put_contents($pathname,json_encode($app),LOCK_EX);
            return $value;
        }

        /**
         * __construct
         * Contructor, inicializa la clase cargando la configuración de la app y la
         * configuración del módulo.
         * Inicializa el UID del usuario y su valor de ABTest
         *
         */
        public function __construct($cms = "none", $cmsContext = null){
            $this->cms = $cms;
            $this->cmsContext = $cmsContext;
            $this->initCookies();

            $this->initAppFile();
            $pathname = realpath(dirname(__FILE__))."/config/app.json";
            if(filesize($pathname)>0){
                $appConfig = json_decode(file_get_contents($pathname),true);
            }else{
                $appConfig = array();
            }

            if(isset($appConfig["url"])){
                $this->url = $appConfig["url"];
            }else{
                $this->url = $this->defaultAppFile["url"];
                $this->setUrl($this->defaultAppFile["url"]);
            }

            if(isset($appConfig["version"])){
                $this->version = $appConfig["version"];
            }else{
                $this->version = $this->defaultAppFile["version"];
                $this->setVersion($this->defaultAppFile["version"]);
            }


            $this->initConfigFile();
            $pathname = realpath(dirname(__FILE__))."/config/config.json";
            $configFile = json_decode(file_get_contents($pathname),true);


            if(isset($configFile["apiKey"])){
                $this->writeLog("[__construct] [apiKey] [OK] update from config.json");
                $this->apiKey = $configFile["apiKey"];
            }else{
                $this->writeLog("[__construct] [apikey] ERROR not in Config File");
                $this->apiKey = $this->defaultConfigFile["apiKey"];
                $this->setApiKey($this->defaultConfigFile["apiKey"]);
            }


            if(isset($configFile["gaActive"])){
                $this->writeLog("[__construct] [gaActive] [OK] update from config.json");
                $this->gaActive = $configFile["gaActive"];
            }else{
                $this->writeLog("[__construct] [gaActive] [ERROR] not in Config File");
                $this->gaActive = $this->defaultConfigFile["gaActive"];
                $this->setGaActive($this->defaultConfigFile["gaActive"]);
            }

            if(isset($configFile["eventsLimit"])){
                $this->writeLog("[__construct] [eventsLimit] [OK] update from config.json");
                $this->eventsLimit = $configFile["eventsLimit"];
            }else{
                $this->writeLog("[__construct] [eventsLimit] [ERROR] not in config.json");
                $this->eventsLimit = $this->defaultConfigFile["eventsLimit"];
                $this->setEventsLimit($this->defaultConfigFile["eventsLimit"]);
            }

            if(isset($configFile["autoSaveGraph"])){
                $this->writeLog("[__construct] [autoSaveGraph] [OK] update from config.json");
                $this->autoSaveGraph = $configFile["autoSaveGraph"];
            }else{
                $this->writeLog("[__construct] [autoSaveGraph] [ERROR] not in Config File");
                $this->autoSaveGraph = $this->defaultConfigFile["autoSaveGraph"];
                $this->setAutoSaveGraph($this->defaultConfigFile["autoSaveGraph"]);
            }

            if(isset($configFile["sortType"])){
                $this->writeLog("[__construct] [sortType] [OK] update from config.json");
                $this->sortType = $configFile["sortType"];
            }else{
                $this->writeLog("[__construct] [sortType] [ERROR] not in Config File");
                $this->sortType = $this->defaultConfigFile["sortType"];
                $this->setSortType($this->defaultConfigFile["sortType"]);
            }

            if(isset($configFile["debug"])){
                $this->writeLog("[__construct] [debug] [OK] update from config.json");
                $this->debug = $configFile["debug"];
            }else{
                $this->writeLog("[__construct] [debug] [ERROR] not in Config File");
                $this->debug = $this->defaultConfigFile["debug"];
                $this->setDebug($this->defaultConfigFile["debug"]);
            }

            $this->initUID();
            $this->initABTest();

            $this->initEvents();
            $this->initAIConfig();

            if($this->sortType == "graphAI"){
                $this->initGraphAI();
            }else{
                $this->initAI();
            }
            $this->writeLog("[__construct] [END]");
            return true;
        }

        function initAIConfig(){
            $this->writeLog("[initAIConfig] [START]");

            $pathname = realpath(dirname(__FILE__))."/config/ai/descend.json";
            if(!file_exists($pathname) || filesize($pathname)==0){
                $this->aiDescend = $this->defaultAIConfig;
                file_put_contents($pathname,json_encode($this->defaultAIConfig),LOCK_EX);
            }else{
                $this->aiDescend = json_decode(file_get_contents($pathname),true);
            }

            $pathname = realpath(dirname(__FILE__))."/config/ai/promote.json";
            if(!file_exists($pathname) || filesize($pathname)==0){
                $this->aiPromote = $this->defaultAIConfig;
                file_put_contents($pathname,json_encode($this->defaultAIConfig),LOCK_EX);
            }else{
                $this->aiPromote = json_decode(file_get_contents($pathname),true);
            }

            $pathname = realpath(dirname(__FILE__))."/config/ai/skip.json";
            if(!file_exists($pathname) || filesize($pathname)==0){
                $this->aiSkip = $this->defaultAIConfig;
                file_put_contents($pathname,json_encode($this->defaultAIConfig),LOCK_EX);
            }else{
                $this->aiSkip = json_decode(file_get_contents($pathname),true);
            }

            $this->writeLog("[initAIConfig] [END]");

        }

        /**
         * initUID
         * Inicializa el valor de UID del usuario almacenándolo en la cookie
         * smartListUID
         *
         * @return string UID
         */
        private function initUID(){
            $smartListUID = $this->getCookie("smartListUID");
            if(!isset($smartListUID)){
                $this->UID=uniqid();
                $this->setCookie("smartListUID", $this->UID);
                $client = array(
                    'event' => '$set',
                    'entityType' => 'user',
                    'entityId' => $this->UID
                );
                $this->sendCreateUser($client);
            }else{
                $this->UID=$this->getCookie("smartListUID");
            }
            return $this->UID;
        }

        /**
         * sendCreateUser
         * Envía al servidor el evento de creación del usuario
         *
         * @return boolean true
         */
        private function sendCreateUser($client){
            $this->writeLog("[createUser] POST: ".json_encode($client,true));
            $options = array(
                'http' => array(
                    'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
                    'method'  => 'POST',
                    'content' => http_build_query($client),
                    'timeout' => 1
                )
            );
            $context  = stream_context_create($options);
            $result = @file_get_contents($this->url.$this->apiKey."/user", false, $context);
            return true;
        }

        /**
         * setUID
         * Fuerza el valor del User Identificator
         *
         * @param string $UID identificador único de usuario
         * @return string identificador único de usuario
         */

        public function setUID($UID){
            $this->UID = $UID;
            $this->setCookie("smartListUID", $this->UID);
            $this->sendCreateUser();
            return $this->UID;
        }

        /**
         * getUID
         * Devuelve el User Identificator
         * @return string identificador único de usuario
         */
        public function getUID(){
            return $this->UID;
        }

        /**
         * initABTest
         * Carga la variable de la case abTest que inidica si el usuario va a sufir
         * personalización o no, con los valores y|n. En caso de no existir la
         * cookie smartListAB lee el fichero var/ab.json de la clase para obtener
         * el valor.
         *
         * @return  String   Valor que indica si se va aplicar la personalización al
         *                   usuario
         */
        private function initABTest(){
            //Comprobamos si el usuario ya cuenta con valor abtest en la cookie
            $smartListAB = $this->getCookie("smartListAB");
            if(!isset($smartListAB)){
                //Si no tiene la cookie de abtest
                //Comprobamos si el fichero var/ab.json exite, sino se inicializa.
                $this->initABConfig();
                $this->initABVar();

                //Leemos el fichero var/ab.json
                $pathname = realpath(dirname(__FILE__))."/config/ab.json";
                $abConfig = json_decode(file_get_contents($pathname),true);

                //Leemos el fichero var/ab.json
                $pathname = realpath(dirname(__FILE__))."/var/ab.json";
                $abVar = json_decode(file_get_contents($pathname),true);

                //Leemos el valor que nos corresponde, lo guardamos en clase y cookie
                $this->abTest = $abConfig["values"][$abVar["position"]];
                $this->setCookie("smartListAB", $this->abTest);

                //Sumamos uno al contador para el siguiente y guardamos
                $abVar["position"] = ($abVar["position"] + 1) % sizeOf($abConfig["values"]);
                $pathname = realpath(dirname(__FILE__))."/var/ab.json";
                file_put_contents($pathname,json_encode($abVar),LOCK_EX);


            }else{
                //Si tiene la cookie de abtest
                //Actualizamos el valor de abTest de la clase con la cookie
                $this->abTest=$this->getCookie("smartListAB");
            }
            return $this->abTest;
        }

        /**
         * initABVar
         * Inicializa la variable var/ab.json que guarda el string de combinaciones
         * y la posición actual para devolver a los usuarios si tienen que usar
         * personalización o no.
         *
         * @return  boolean   éxito de la operación
         */
        private function initABVar(){
            //Comprueba si existe el fichero /var/ab.json
            $pathname = realpath(dirname(__FILE__))."/var/ab.json";
            if(!file_exists($pathname) || filesize($pathname)==0){
                //Si no existe
                //Almacena defaultABVar en /var/ab.json
                file_put_contents($pathname,json_encode($this->defaultABVar),LOCK_EX);
            }
            //Devuelve true
            return true;
        }

        private function initABConfig(){
            //Comprueba si existe el fichero /config/ab.json
            $pathname = realpath(dirname(__FILE__))."/config/ab.json";
            if(!file_exists($pathname) || filesize($pathname)==0){
                //Si no existe
                //Almacena defaultABConfig en /config/ab.json
                file_put_contents($pathname,json_encode($this->defaultABConfig),LOCK_EX);
            }
            //Devuelve true
            return true;
        }


        /**
         * initConfigFile
         * Inicializa el fichero de configurtación config/configjson que guarda el
         * apiKey de este módulo.
         *
         * @return  boolean   éxito de la operación
         */
        private function initConfigFile(){
            $this->writeLog("[initConfigFile] [START]");
            //Comprueba si existe el fichero config/config.json

            $pathname = realpath(dirname(__FILE__))."/config/config.json";
            if(!file_exists($pathname) || filesize($pathname)==0){
                $this->writeLog("[initConfigFile] [ERROR] File doesn't exists or empty");
                //Si no existe
                //Almacena defaultConfigFile en config/config.json
                file_put_contents($pathname,json_encode($this->defaultConfigFile),LOCK_EX);
                $this->writeLog("[initConfigFile] [INFO] Writed defaultConfigFile");
            }
            $this->writeLog("[initConfigFile] [END]");

            return true;

        }

        /**
         * initAppFile
         * Inicializa el fichero de configurtación config/configjson que guarda el
         * apiKey de este módulo.
         *
         * @return  boolean   éxito de la operación
         */
        private function initAppFile(){

            //Comprueba si existe el fichero config/app.json
            $pathname = realpath(dirname(__FILE__))."/config/app.json";
            if(!file_exists($pathname) || filesize($pathname)==0){
                //Si no existe
                //Almacena defaultConfigFile en config/config.json
                file_put_contents($pathname,json_encode($this->defaultAppFile),LOCK_EX);
            }
            return true;
        }

        /**
         * createEvent
         * Envía información al servidor de predicción para entrenamiento.
         *
         * @param  string  $action   Acción realizada
         * @param  array   $item     Datos del producto
         * @return boolean           Resultado del envío del la información
         */
        public function createEvent($action,$item){
            if(isset($item["IID"])){
                $event = array(
                    "event" => $action,
                    "entityType" => "user",
                    "entityId" => $this->UID,
                    "abTest" => $this->abTest,
                    "targetEntityType" => "item",
                    "targetEntityId" => $item["IID"],
                    "properties" => $item["properties"]
                );

                $this->writeLog("[createEvent] POST: ".json_encode($event,true));

                $options = array(
                    'http' => array(
                        'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
                        'method'  => 'POST',
                        'content' => http_build_query($event),
                        'timeout' => 1
                    )
                );
                $context  = stream_context_create($options);
                $result = @file_get_contents($this->url.$this->apiKey."/event", false, $context);

                if($action != "list"){
                    if($this->sortType == "graphAI"){
                        $this->setLocalGraph($event);
                    }else{
                        $this->setLocalEvent($event);
                    }
                }

                return true;
            }else{
                return false;
            }
        }

        private function initEvents(){
            $this->writeLog("[initEvents] [START]");

            $smartListEvents = $this->getCookie("smartListEvents");
            if(!isset($smartListEvents)){
                $this->writeLog("[initEvents] [ERROR] Doesn't have smartListEvents");
                $this->events = array();
                $this->setCookie("smartListEvents",json_encode($this->events));
                $this->writeLog("[initEvents] [INFO] Cookie Init");
            }else{
                $this->events = json_decode($smartListEvents,true);
                $this->writeLog("[initEvents] [OK] smartListEvents from Cookie Init");
                $this->writeLog("[initEvents] [INFO] Size: ".sizeOf($this->events));
            }
            $this->writeLog("[initEvents] [END]");
            return $this->events;
        }

        /**
         * setLocalEvent
         * Deprecated
         *
         * Guarda localmente los productos con los que se ha interactuado
         *
         * @param object $event evento que se ha realizado
         * @return array Listado de eventos almacenados
         */
        private function setLocalEvent($event){
            $this->writeLog("[setLocalEvent] START");

            array_unshift($this->events,$event);
            while(sizeOf($this->events)>$this->eventsLimit){
                array_pop($this->events);
            }

            $this->setCookie("smartListEvents",json_encode($this->events));

            $this->writeLog("[setLocalEvent] END");
            return $this->events;
        }

        /**
         * setLocalGraph
         * Guarda localmente los productos con los que se ha interactuado
         *
         * @param object $event evento que se ha realizado
         * @return array Listado de eventos almacenados
         */
        private function setLocalGraph($event){
            $this->writeLog("[setLocalGraph] START");

            if(isset($event["event"]) && isset($event["targetEntityId"])){
                $eAction = $event["event"];
                $eIID = $event["targetEntityId"];
                $step = 0;
                if(isset($this->events) && (sizeOf($this->events)>0)){
                    foreach($this->events as $key => $pastEvent){
                        if(isset($pastEvent["IID"])){
                            $iIID = $pastEvent["IID"];
                            if($this->autoSaveGraph){
                                $this->increaseGraphValue($eAction,$eIID,$iIID,$step);
                            }
                            $step++;
                        }else{
                            $this->writeLog("[setLocalGraph] [ERROR] older events don't have IID targetEntityId");
                        }
                    }
                }
                $pastEvent = array(
                    "event" => $event["event"],
                    "IID" => $event["targetEntityId"]
                );
                array_unshift($this->events,$pastEvent);
                while(sizeOf($this->events)>$this->eventsLimit){
                    array_pop($this->events);
                }
                $this->setCookie("smartListEvents",json_encode($this->events));
            }else{
                $this->writeLog("[setLocalGraph] [ERROR] new event don't have event or targetEntityId");
            }

            $this->writeLog("[setLocalGraph] END");
            return $this->events;
        }

        public function sort($itemsList){
            if($this->sortType == "graphAI"){
                return $this->graphSortAI($itemsList);
            }else{
                return $this->sortAI($itemsList);
            }
        }

        public function sortAI($itemsList){
            usort($itemsList,function ($a, $b) {
                if(isset($a["sortField"])){
                    $a=$a["sortField"];
                }
                if(isset($b["sortField"])){
                    $b=$b["sortField"];
                }
                $prefA = $this->calcPreference($a);
                $prefB = $this->calcPreference($b);
                if ($prefA == $prefB) {
                    return 0;
                }else{
                    return ($prefA > $prefB) ? -1 : 1;
                }
            });

            return $itemsList;
        }

        /**
         * calcPreference
         * description
         *
         * @param  [type] $item [description]
         * @return [type]       [description]
         */
        private function calcPreference($item){

            $score = 0;
            if(sizeOf($this->events)>0){
                foreach ($this->events as $i => $event){
                    foreach($event["properties"] as $key => $value){
                        if(!isset($this->ai[$key])){
                            $this->updateAI($key,100);
                        }
                        if(!is_array($value)){
                            if(isset($item["properties"][$key])){
                                if(!is_array($item["properties"][$key])){
                                    if($value == $item["properties"][$key]){
                                        $score += $this->ai[$key];
                                    }
                                }
                            }else{
                                if(isset($item["properties"][$key])){
                                    foreach($item["properties"][$key] as $none => $valueArray){
                                        if($value == $valueArray){
                                            $score += $this->ai[$key];
                                        }
                                    }
                                }
                            }
                        }else{
                            foreach($value as $none => $valueArray){
                                if(isset($item["properties"][$key])){
                                    if(!is_array($item["properties"][$key])){
                                        if($valueArray == $item["properties"][$key]){
                                            $score += $this->ai[$key];
                                        }
                                    }
                                }else{
                                    if(isset($item["properties"][$key])){
                                        foreach($item["properties"][$key] as $none => $valueArray2){
                                            if($valueArray == $valueArray2){
                                                $score += $this->ai[$key];
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $this->writeLog("[calcPreference] ".$item["IID"].": ".$score);
            return $score;
        }

        public function graphSortAI($itemsList){
            usort($itemsList,function ($a, $b) {
                if(isset($a["sortField"])){
                    $a=$a["sortField"];
                }
                if(isset($b["sortField"])){
                    $b=$b["sortField"];
                }
                if(isset($a["IID"]) && isset($b["IID"])){
                    $prefA = $this->graphDistance($a);
                    $prefB = $this->graphDistance($b);
                    if ($prefA == $prefB) {
                        return 0;
                    }else{
                        return ($prefA > $prefB) ? -1 : 1;
                    }
                }
                return 0;
            });
            return $itemsList;
        }

        private function AIConfigScoring($item){
            $score = 0;
            $promoted = false;
            if(($item["IID"]==$this->aiPromote["IID"]) || (@in_array($item["IID"],$this->aiPromote["IID"]))){
                $score = (100 * $this->eventsLimit) + 1;
                $promoted = true;
            }else{
                if(isset($this->aiPromote["properties"]) && sizeOf($this->aiPromote["properties"]>0)){
                    foreach($this->aiPromote["properties"] as $promoteKey=>$promoteValue){
                        if(!$promoted){
                            if(isset($item["properties"][$promoteKey])){
                                if(($item["properties"][$promoteKey]==$promoteValue) || (@in_array($item["properties"][$promoteKey],$promoteValue))){
                                    $score = (100 * $this->eventsLimit) + 1;
                                    $promoted = true;
                                }
                            }
                        }
                    }
                }
            }

            $descended = false;
            if(($item["IID"]==$this->aiDescend["IID"]) || (@in_array($item["IID"],$this->aiDescend["IID"]))){
                $score = (-100 * $this->eventsLimit) - 1;
                $descended = true;
            }else{
                if(isset($this->aiDescend["properties"]) && sizeOf($this->aiDescend["properties"]>0)){
                    foreach($this->aiDescend["properties"] as $descendKey=>$descendValue){
                        if(!$descended){
                            if(isset($item["properties"][$descendKey])){
                                if(($item["properties"][$descendKey]==$descendValue) || (@in_array($item["properties"][$descendKey],$descendValue))){
                                    $score = (-100 * $this->eventsLimit) - 1;
                                    $descended = true;
                                }
                            }
                        }
                    }
                }
            }
            return $score;

        }

        private function graphDistance($item){
            $score = 0;
            if(sizeOf($this->events)>0){
                foreach ($this->events as $i => $event){
                    if(isset($event["event"]) && isset($event["IID"]) && isset($item["IID"])){
                        $eAction = $event["event"];
                        $eIID = $event["IID"];
                        $iIID = $item["IID"];
                        if(isset($this->graphAI[$eAction][$eIID][$iIID])){
                            $score += $this->graphAI[$eAction][$eIID][$iIID];
                        }
                    }
                }
            }

            $score += $this->AIConfigScoring($item);

            $this->writeLog("[graphDistance] ".$item["IID"]." : ".$score);
            return $score;
        }

        private function increaseGraphValue($eAction,$eIID,$iIID,$step){
            $this->writeLog("[increaseGraphValue] [".$eAction." | ".$eIID." | ".$iIID."]");

            $this->initGraphValue($eAction,$eIID,$iIID);
            if($this->graphAI[$eAction][$eIID][$iIID]<100){
                $increase = round(($this->eventsLimit - $step) / $this->eventsLimit,4);
                $this->graphAI[$eAction][$eIID][$iIID] = $this->graphAI[$eAction][$eIID][$iIID] + $increase;
                if ($this->graphAI[$eAction][$eIID][$iIID]>100){
                    $this->graphAI[$eAction][$eIID][$iIID] = 100;
                }
            }
            $this->saveGraph();
        }

        private function initGraphValue($eAction,$eIID,$iIID){
            $this->writeLog("[initGraphValue] [".$eAction." | ".$eIID." | ".$iIID."]");

            if(isset($this->graphAI[$eAction][$eIID])){
                if(!isset($this->graphAI[$eAction][$eIID][$iIID])){
                    $this->graphAI[$eAction][$eIID][$iIID] = 0;
                }
            }else{
                if(isset($this->graphAI[$eAction])){
                    $this->graphAI[$eAction][$eIID] = array();
                    $this->graphAI[$eAction][$eIID][$iIID] = 0;
                }else{
                    $this->graphAI[$eAction] = array();
                    $this->graphAI[$eAction][$eIID] = array();
                    $this->graphAI[$eAction][$eIID][$iIID] = 0;
                }
            }

            $this->saveGraph();
        }

        private function saveGraph(){
            $pathname = realpath(dirname(__FILE__))."/var/graphai.json";
            file_put_contents($pathname,json_encode($this->graphAI),LOCK_EX);
        }

        /**
         * sendQuery
         * Envía una soliciud de ordenación de productos dependiendo de la probabilidad
         *
         * @param  array $itemList [Listado de Identificadores de Productos a ordenar]
         * @return array           [description]
         */

        public function sendQuery($itemList){
            if($this->abTest == "y"){
                $query = array(
                    "user" => $this->UID,
                    "items" => $itemList
                );
                $this->writeLog("[sendQuery] POST: ".json_encode($query,true));
                $options = array(
                    'http' => array(
                        'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
                        'method'  => 'POST',
                        'content' => http_build_query($query),
                        'timeout' => 1
                    )
                );
                $context  = stream_context_create($options);
                $result = @file_get_contents($this->url.$this->apiKey."/query", false, $context);
                return $result;
            }else{
                return $itemList;
            }
        }

        private function initAI(){
            $this->writeLog("[initAI] [START]");

            $pathname = realpath(dirname(__FILE__))."/var/ai.json";
            if(!file_exists($pathname) || filesize($pathname)==0){
                file_put_contents($pathname,json_encode(array()),LOCK_EX);
            }
            $ai = json_decode(file_get_contents($pathname),true);
            $this->ai=$ai;
            $this->writeLog("[initAI] [END]");

        }

        private function initGraphAI(){
            $this->writeLog("[initGraphAI] [START]");
            $pathname = realpath(dirname(__FILE__))."/var/graphai.json";
            if(!file_exists($pathname) || filesize($pathname)==0){
                file_put_contents($pathname,json_encode(array()),LOCK_EX);
            }
            $graphAI = json_decode(file_get_contents($pathname),true);
            $this->graphAI=$graphAI;
            $this->writeLog("[initGraphAI] [END]");
        }

        private function updateAI($key,$value){
            $this->ai[$key]=$value;
            $this->setAI($this->ai);
        }

        /**
         * setAI
         * description
         *
         * @param [type] $ai [description]
         */
        public function setAI($ai){

            $pathname = realpath(dirname(__FILE__))."/var/ai.json";
            file_put_contents($pathname,json_encode($this->ai),LOCK_EX);

        }

        public function setGraphAI($graphAI){
            $this->initGraphAI();
            $pathname = realpath(dirname(__FILE__))."/var/graphai.json";
            file_put_contents($pathname,json_encode($this->ai),LOCK_EX);
        }

        /**
         * getAI
         * description
         *
         * @return [type] [description]
         */
        public function getAI(){
            $pathname = realpath(dirname(__FILE__))."/var/ai.json";
            $ai = file_get_contents($pathname);
            return $ai;
        }

        /**
         * syncAI
         * description
         *
         * @return [type] [description]
         */
        public function syncAI(){

            $this->writeLog("[syncAI]");
            $options = array(
                'http' => array(
                    'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
                    'method'  => 'GET',
                    'timeout' => 1
                )
            );
            $context  = stream_context_create($options);
            if($this->sortType == "graphAI"){
                $result = @file_get_contents($this->url.$this->apiKey."/graphai", false, $context);
                $result = json_decode($result,true);
                $this->graphAI = array();
                foreach($result["graphAI"] as $key => $value){
                    $this->graphAI[$key]=$value;
                }
                $this->setGraphAI($result["graphAI"]);

            }else{
                $result = @file_get_contents($this->url.$this->apiKey."/ai", false, $context);
                $result = json_decode($result,true);
                $this->ai = array();
                foreach($result["ai"] as $key => $value){
                    $this->ai[$key]=$value;
                }
                $this->setAI($result["ai"]);

            }

        }
    }
}
