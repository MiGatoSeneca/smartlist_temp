<?php
  require "../smartlist.php";

  $smartlist = new SmartList();

  $smartlist->syncAI();
?>
