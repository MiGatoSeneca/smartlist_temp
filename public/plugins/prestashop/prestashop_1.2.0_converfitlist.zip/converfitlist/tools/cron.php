<?php
  require realpath(dirname(__FILE__))."/../smartlist/smartlist.php";

  $smartlist = new SmartList("none");

  if($_GET["apiKey"]==$smartlist->getApiKey()){
    $smartlist->syncAI();
  }
?>
