<?php
  require "../smartlist.php";

  $smartlist = new SmartList("none");

  $smartlist->syncAI();
?>
