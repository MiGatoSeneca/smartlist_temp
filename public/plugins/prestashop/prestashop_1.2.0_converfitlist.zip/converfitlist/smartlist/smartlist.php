<?php

/*
 * Copyright (c) 2017, Converfit. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * All rights reserved. No part of this code may be reproduced,
 * distributed, or transmitted in any form or by any means without
 * the prior written permission of the publisher, except in the
 * case of brief quotations embodied in critical reviews and certain
 * other noncommercial uses permitted by copyright law. For permission
 * requests, write to the publisher, at the address below.
 *
 * Please contact us via email at info@converfit.com
 *
 * www.converfit.com
 *
 * @author Converfit Team
 * @version 1.0
 */

 if (!class_exists('SmartList')) {
   class SmartList {

     private $defaultAppFile = array(
       "version" => "1.2.0",
       "url" => "http://smartlist.conver.fit/api/"
     );

     private $defaultConfigFile = array(
       "apiKey" => "your_apikey",
       "gaActive" => false,
       "eventsLimit" => "5",
       "syncPeriod" => "10",
       "debug" => "local"
     );

     public function setGaActive($value){
       $this->gaActive = $value;
       return $this->setConfigValue("gaActive",$value);
     }
     public function getGaActive(){
       return $this->gaActive;
     }
     public function getGaScript(){
       $html = "";
       $html .= "$(document).ready(function() {";
       $html .= " if(typeof ga !== 'undefined'){";
       $html .= "   ga('send', 'event', 'Converfit','SmartList','smartlist_".$this->getAbTest()."');";
       $html .= " }";
       $html .= "});";
       return $html;

     }


     public function sendLog($str){
       $data = array(
         "str"=> $str
       );

       $options = array(
           'http' => array(
               'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
               'method'  => 'POST',
               'content' => http_build_query($data),
               'timeout' => 1
           )
       );
       $context  = stream_context_create($options);
       $result = @file_get_contents($this->url.$this->apiKey."/log", false, $context);

     }

     private function writeLog($str){
       if($this->debug == "local"){
         error_log("[".$this->apiKey."] ".$str);
       }else if($this->debug == "server"){
         $this->sendLog($str);
       }
     }





     private $defaultABVar = array(
       "values" => array("y","y","y","y","y","y","y","y","y","n"),
       "position" =>0
     );

     private $url = '';
     private $version = '';
     private $debug = '';

     private $cms = '';
     private $cmsCookie = '';
     private $cookie = array();

     private $apiKey = '';
     private $eventsLimit = '';
     private $gaActive = false;

     private $classPath = '';
     private $UID = '';
     private $abTest = '';
     private $ai = '';

     private $syncPeriod = '';



     public function getABTest(){
       $response = "no";
       if($this->abTest == "y"){
         $response = "yes";
       }
       return $response;
     }


     private function initCookies(){
       if(isset($this->cms) && ($this->cms=="Prestashop")){
         if(file_exists('config/config.inc.php')){
           include_once('config/config.inc.php');
         }
         if(file_exists('config/settings.inc.php')){
           include_once('config/settings.inc.php');
         }
         if(file_exists('classes/Cookie.php')){
           include_once('classes/Cookie.php');
         }
         $this->cmsCookie = new Cookie("Smartlist");
         if(!isset($this->cmsCookie->smartList)){
           $this->cmsCookie->smartList="{}";
           $this->cookie = array();
         }else{
           $this->cookie = json_decode($this->cmsCookie->smartList,true);
         }

       }
     }

     private function getCookie($key){
       if(isset($this->cms) && ($this->cms=="Prestashop")){
         if(isset($this->cookie[$key])){
           return $this->cookie[$key];
         }else{
           return null;
         }
       }else{
         return $_COOKIE[$key];
       }
     }

     private function setCookie($key,$value){
       if(isset($this->cms) && ($this->cms=="Prestashop")){
         $this->writeLog("[setCookie]");
         $this->cookie[$key] = $value;
         $this->cmsCookie->smartList=json_encode($this->cookie);
         error_log($this->cmsCookie->write());
       }else{
         setcookie($key,$value);
       }
     }







     public function getEventsLimit(){
       return $this->eventsLimit;
     }
     public function setEventsLimit($value){
       $this->eventsLimit = $value;
       return $this->setConfigValue("eventsLimit",$value);
     }










     public function getSyncPeriod(){
       return $this->syncPeriod;
     }

     public function setSyncPeriod($value){
       $this->syncPeriod = $value;
       return $this->setConfigValue("syncPeriod",$value);
     }

     /**
      * getUrl
      * Duelve la url utilizada para conectarse con el servidor de predicción
      *
      * @return string url del servidor de predicción
      */
     public function getDebug(){
       return $this->debug;
     }

     /**
      * setUrl
      * Actualiza la url utilizada para conectarse con el servidor de predicción
      *
      * @return string url del servidor de predicción
      */
     public function setDebug($value){
       $this->debug = $value;
       return $this->setConfigValue("debug",$value);
     }



     /**
      * getUrl
      * Duelve la url utilizada para conectarse con el servidor de predicción
      *
      * @return string url del servidor de predicción
      */
     public function getUrl(){
       return $this->url;
     }

     /**
      * setUrl
      * Actualiza la url utilizada para conectarse con el servidor de predicción
      *
      * @return string url del servidor de predicción
      */
     public function setUrl($value){
       $this->url = $value;
       return $this->setAppValue("url",$value);
     }

     /**
      * getUrl
      * Duelve la url utilizada para conectarse con el servidor de predicción
      *
      * @return string url del servidor de predicción
      */
     public function getVersion(){
       return $this->version;
     }

     /**
      * setUrl
      * Actualiza la url utilizada para conectarse con el servidor de predicción
      *
      * @return string url del servidor de predicción
      */
     private function setVersion($value){
       $this->version = $value;
       return $this->setAppValue("version",$value);
     }



     /**
      * getApiKey
      * Devuelve el apiKey utilizado actualmente
      *
      * @return string llave de acceso al API del servidor
      */
     public function getApiKey(){
       return $this->apiKey;
     }

     /**
      * setApiKey
      * Actualiza el apiKey utilizado
      * config/config.json
      *
      * @param string $apiKey Nueva llave a almacenar
      */
     public function setApiKey($value){
       $this->apiKey = $value;
       return $this->setConfigValue("apiKey",$value);
     }







     private function setConfigValue($key,$value){
       $this->initConfigFile();

       $pathname = realpath(dirname(__FILE__))."/config/config.json";
       $config = json_decode(file_get_contents($pathname),true);
       $config[$key] = $value;
       file_put_contents($pathname,json_encode($config),LOCK_EX);
       return $value;

     }

     private function setAppValue($key,$value){
       $this->initConfigFile();

       $pathname = realpath(dirname(__FILE__))."/config/app.json";
       $app = json_decode(file_get_contents($pathname),true);
       $app[$key] = $value;
       file_put_contents($pathname,json_encode($app),LOCK_EX);
       return $value;
     }




     /**
      * __construct
      * Contructor, inicializa la clase cargando la configuración de la app y la
      * configuración del módulo.
      * Inicializa el UID del usuario y su valor de ABTest
      *
      */

     public function __construct($cms){

       $this->cms = $cms;
       $this->initCookies();


       $this->initAppFile();
       $pathname = realpath(dirname(__FILE__))."/config/app.json";
       if(filesize($pathname)>0){
         $appConfig = json_decode(file_get_contents($pathname),true);
       }else{
         $appConfig = array();
       }

       if(isset($appConfig["url"])){
         $this->url = $appConfig["url"];
       }else{
         $this->url = $this->defaultAppFile["url"];
         $this->setUrl($this->defaultAppFile["url"]);
       }

       if(isset($appConfig["version"])){
         $this->version = $appConfig["version"];
       }else{
         $this->version = $this->defaultAppFile["version"];
         $this->setVersion($this->defaultAppFile["version"]);
       }


       $this->initConfigFile();
       $pathname = realpath(dirname(__FILE__))."/config/config.json";
       $configFile = json_decode(file_get_contents($pathname),true);


       if(isset($configFile["apiKey"])){
         $this->writeLog("[__construct] [apiKey] [OK] update from config.json");
         $this->apiKey = $configFile["apiKey"];
       }else{
         $this->writeLog("[__construct] [apikey] ERROR not in Config File");
         $this->apiKey = $this->defaultConfigFile["apiKey"];
         $this->setApiKey($this->defaultConfigFile["apiKey"]);
       }


       if(isset($configFile["gaActive"])){
         $this->writeLog("[__construct] [gaActive] [OK] update from config.json");
         $this->gaActive = $configFile["gaActive"];
       }else{
         $this->writeLog("[__construct] [gaActive] [ERROR] not in Config File");
         $this->gaActive = $this->defaultConfigFile["gaActive"];
         $this->setGaActive($this->defaultConfigFile["gaActive"]);
       }

       if(isset($configFile["eventsLimit"])){
         $this->writeLog("[__construct] [eventsLimit] [OK] update from config.json");
         $this->eventsLimit = $configFile["eventsLimit"];
       }else{
         $this->writeLog("[__construct] [eventsLimit] [ERROR] not in config.json");
         $this->eventsLimit = $this->defaultConfigFile["eventsLimit"];
         $this->setEventsLimit($this->defaultConfigFile["eventsLimit"]);
       }

       if(isset($configFile["syncPeriod"])){
         $this->writeLog("[__construct] [syncPeriod] [OK] update from config.json");
         $this->syncPeriod = $configFile["syncPeriod"];
       }else{
         $this->writeLog("[__construct] [syncPeriod] [ERROR] not in Config File");
         $this->syncPeriod = $this->defaultConfigFile["syncPeriod"];
         $this->setSyncPeriod($this->defaultConfigFile["syncPeriod"]);
       }

       if(isset($configFile["debug"])){
         $this->writeLog("[__construct] [debug] [OK] update from config.json");
         $this->debug = $configFile["debug"];
       }else{
         $this->writeLog("[__construct] [debug] [ERROR] not in Config File");
         $this->debug = $this->defaultConfigFile["debug"];
         $this->setDebug($this->defaultConfigFile["debug"]);
       }

       $this->initUID();
       $this->initABTest();

       $this->initEvents();
       $this->initAI();

       return true;
     }




     /**
      * initUID
      * Inicializa el valor de UID del usuario almacenándolo en la cookie
      * smartListUID
      *
      * @return string UID
      */

     private function initUID(){
       $smartListUID = $this->getCookie("smartListUID");
       if(!isset($smartListUID)){
         $this->UID=uniqid();
         $this->setCookie("smartListUID", $this->UID);
         $client = array(
           'event' => '$set',
           'entityType' => 'user',
           'entityId' => $this->UID
         );
         $this->sendCreateUser($client);
       }else{
         $this->UID=$this->getCookie("smartListUID");
       }
       return $this->UID;
     }

     /**
      * sendCreateUser
      * Envía al servidor el evento de creación del usuario
      *
      * @return boolean true
      */

     private function sendCreateUser($client){
       $this->writeLog("[createUser] POST: ".json_encode($client,true));
       $options = array(
           'http' => array(
               'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
               'method'  => 'POST',
               'content' => http_build_query($client),
               'timeout' => 1
           )
       );
       $context  = stream_context_create($options);
       $result = @file_get_contents($this->url.$this->apiKey."/user", false, $context);
       return true;
     }

     /**
      * setUID
      * Fuerza el valor del User Identificator
      *
      * @param string $UID identificador único de usuario
      * @return string identificador único de usuario
      */

     public function setUID($UID){
       $this->UID = $UID;
       $this->setCookie("smartListUID", $this->UID);
       $this->sendCreateUser();
       return $this->UID;
     }

     /**
      * getUID
      * Devuelve el User Identificator
      * @return string identificador único de usuario
      */
     public function getUID(){
       return $this->UID;
     }

     /**
      * initABTest
      * Carga la variable de la case abTest que inidica si el usuario va a sufir
      * personalización o no, con los valores y|n. En caso de no existir la
      * cookie smartListAB lee el fichero var/ab.json de la clase para obtener
      * el valor.
      *
      * @return  String   Valor que indica si se va aplicar la personalización al
      *                   usuario
      */

     private function initABTest(){
       //Comprobamos si el usuario ya cuenta con valor abtest en la cookie
       $smartListAB = $this->getCookie("smartListAB");
       if(!isset($smartListAB)){
         //Si no tiene la cookie de abtest
         //Comprobamos si el fichero var/ab.json exite, sino se inicializa.
         $this->initABVar();

         //Leemos el fichero var/ab.json
         $pathname = realpath(dirname(__FILE__))."/var/ab.json";
         $abJSON = json_decode(file_get_contents($pathname),true);

         //Leemos el valor que nos corresponde, lo guardamos en clase y cookie
         $this->abTest = $abJSON["values"][$abJSON["position"]];
         $this->setCookie("smartListAB", $this->abTest);

         //Sumamos uno al contador para el siguiente y guardamos
         $abJSON["position"] = ($abJSON["position"] + 1) % 10;
         $pathname = realpath(dirname(__FILE__))."/var/ab.json";
         file_put_contents($pathname,json_encode($abJSON),LOCK_EX);


       }else{
         //Si tiene la cookie de abtest
         //Actualizamos el valor de abTest de la clase con la cookie
         $this->abTest=$this->getCookie("smartListAB");
       }
       return $this->abTest;
     }


     /**
      * initABVar
      * Inicializa la variable var/ab.json que guarda el string de combinaciones
      * y la posición actual para devolver a los usuarios si tienen que usar
      * personalización o no.
      *
      * @return  boolean   éxito de la operación
      */

     private function initABVar(){
       //Comprueba si existe el fichero /var/ab.json
       $pathname = realpath(dirname(__FILE__))."/var/ab.json";
       if(!file_exists($pathname) || filesize($pathname)==0){
         //Si no existe
         //Almacena defaultABVar en /var/ab.json
         file_put_contents($pathname,json_encode($this->defaultABVar),LOCK_EX);
       }
       //Devuelve true
       return true;
     }


     /**
      * initConfigFile
      * Inicializa el fichero de configurtación config/configjson que guarda el
      * apiKey de este módulo.
      *
      * @return  boolean   éxito de la operación
      */

     private function initConfigFile(){
       $this->writeLog("[initConfigFile] [START]");
       //Comprueba si existe el fichero config/config.json

       $pathname = realpath(dirname(__FILE__))."/config/config.json";
       if(!file_exists($pathname) || filesize($pathname)==0){
         $this->writeLog("[initConfigFile] [ERROR] File doesn't exists or empty");
         //Si no existe
         //Almacena defaultConfigFile en config/config.json
         file_put_contents($pathname,json_encode($this->defaultConfigFile),LOCK_EX);
         $this->writeLog("[initConfigFile] [INFO] Writed defaultConfigFile");
       }
       $this->writeLog("[initConfigFile] [END]");

       return true;

     }


     /**
      * initAppFile
      * Inicializa el fichero de configurtación config/configjson que guarda el
      * apiKey de este módulo.
      *
      * @return  boolean   éxito de la operación
      */

     private function initAppFile(){

       //Comprueba si existe el fichero config/app.json
       $pathname = realpath(dirname(__FILE__))."/config/app.json";
       if(!file_exists($pathname) || filesize($pathname)==0){
         //Si no existe
         //Almacena defaultConfigFile en config/config.json
         file_put_contents($pathname,json_encode($this->defaultAppFile),LOCK_EX);
       }
       return true;
     }


     /**
      * createEvent
      * Envía información al servidor de predicción para entrenamiento.
      *
      * @param  string  $action   Acción realizada
      * @param  array   $item     Datos del producto
      * @return boolean           Resultado del envío del la información
      */

     public function createEvent($action,$item){
       if(isset($item["IID"])){
         $event = array(
           "event" => $action,
           "entityType" => "user",
           "entityId" => $this->UID,
           "abTest" => $this->abTest,
           "targetEntityType" => "item",
           "targetEntityId" => $item["IID"],
           "properties" => $item["properties"]
         );

         $this->writeLog("[createEvent] POST: ".json_encode($event,true));

         $options = array(
             'http' => array(
                 'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
                 'method'  => 'POST',
                 'content' => http_build_query($event),
                 'timeout' => 1
             )
         );
         $context  = stream_context_create($options);
         $result = @file_get_contents($this->url.$this->apiKey."/event", false, $context);

         $this->setLocalEvent($event);

         return true;
       }else{
         return false;
       }
     }

     private function initEvents(){
       $this->writeLog("[initEvents] [START]");

       $smartListEvents = $this->getCookie("smartListEvents");
       if(!isset($smartListEvents)){
         $this->writeLog("[initEvents] [ERROR] Doesn't have smartListEvents");
         $events = array();
         $this->setCookie("smartListEvents",json_encode($events));
         $this->writeLog("[initEvents] [INFO] Cookie Init");
       }else{
         $this->events = json_decode($this->getCookie("smartListEvents"),true);
         $this->writeLog("[initEvents] [OK] smartListEvents from Cookie Init");
         $this->writeLog("[initEvents] [INFO] Size: ".sizeOf($this->events));
       }
       $this->writeLog("[initEvents] [END]");
       return $this->events;
     }

     /**
      * setLocalEvent
      * Guarda localmente los productos con los que se ha interactuado
      *
      * @param object $event evento que se ha realizado
      * @return array Listado de eventos almacenados
      */
     private function setLocalEvent($event){
       $this->writeLog("[setLocalEvent] START");
       array_unshift($this->events,$event);
       while(sizeOf($this->events)>$this->eventsLimit){
         array_pop($this->events);
       }

       $this->setCookie("smartListEvents",json_encode($this->events));

       $this->writeLog("[setLocalEvent] END");
       return $this->events;
     }

     public function sort($itemsList){
       usort($itemsList,function ($a, $b) {
         if(isset($a["sortField"])){
           $a=$a["sortField"];
         }
         if(isset($b["sortField"])){
           $b=$b["sortField"];
         }
         $prefA = $this->calcPreference($a);
         $prefB = $this->calcPreference($b);
         if ($prefA == $prefB) {
           return 0;
         }else{
           return ($prefA > $prefB) ? -1 : 1;
         }
       });

       return $itemsList;
     }

     /**
      * calcPreference
      * description
      *
      * @param  [type] $item [description]
      * @return [type]       [description]
      */
     private function calcPreference($item){

       $score = 0;
       if(sizeOf($this->events)>0){
         foreach ($this->events as $i => $event){
           foreach($event["properties"] as $key => $value){
             if(!isset($this->ai[$key])){
               $this->updateAI($key,100);
             }
             if(!is_array($value)){
               if(isset($item["properties"][$key])){
                 if(!is_array($item["properties"][$key])){
                   if($value == $item["properties"][$key]){
                     $score += $this->ai[$key];
                   }
                 }
               }else{
                 if(isset($item["properties"][$key])){
                   foreach($item["properties"][$key] as $none => $valueArray){
                     if($value == $valueArray){
                       $score += $this->ai[$key];
                     }
                   }
                 }
               }
             }else{
               foreach($value as $none => $valueArray){
                 if(isset($item["properties"][$key])){
                   if(!is_array($item["properties"][$key])){
                     if($valueArray == $item["properties"][$key]){
                       $score += $this->ai[$key];
                     }
                   }
                 }else{
                   if(isset($item["properties"][$key])){
                     foreach($item["properties"][$key] as $none => $valueArray2){
                       if($valueArray == $valueArray2){
                         $score += $this->ai[$key];
                       }
                     }
                   }
                 }
               }
             }
           }
         }
       }
       return $score;
     }



     /**
      * sendQuery
      * Envía una soliciud de ordenación de productos dependiendo de la probabilidad
      *
      * @param  array $itemList [Listado de Identificadores de Productos a ordenar]
      * @return array           [description]
      */

     public function sendQuery($itemList){
       if($this->abTest == "y"){
         $query = array(
           "user" => $this->UID,
           "items" => $itemList
         );
         $this->writeLog("[sendQuery] POST: ".json_encode($query,true));
         $options = array(
             'http' => array(
                 'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
                 'method'  => 'POST',
                 'content' => http_build_query($query),
                 'timeout' => 1
             )
         );
         $context  = stream_context_create($options);
         $result = @file_get_contents($this->url.$this->apiKey."/query", false, $context);
         return $result;
       }else{
         return $itemList;
       }
     }

     private function initAI(){
       $pathname = realpath(dirname(__FILE__))."/var/ai.json";
       $ai = json_decode(file_get_contents($pathname),true);
       $this->ai=$ai;
     }

     private function updateAI($key,$value){
       $this->ai[$key]=$value;
       $this->setAI($this->ai);
     }


   /**
    * setAI
    * description
    *
    * @param [type] $ai [description]
    */

     public function setAI($ai){

       $pathname = realpath(dirname(__FILE__))."/var/ai.json";
       file_put_contents($pathname,json_encode($this->ai),LOCK_EX);

     }

     /**
      * getAI
      * description
      *
      * @return [type] [description]
      */

     public function getAI(){
       $pathname = realpath(dirname(__FILE__))."/var/ai.json";
       $ai = file_get_contents($pathname);
       return $ai;
     }


     /**
      * syncAI
      * description
      *
      * @return [type] [description]
      */
     public function syncAI(){

       $this->writeLog("[syncAI]");
       $options = array(
           'http' => array(
               'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
               'method'  => 'GET',
               'timeout' => 1
           )
       );
       $context  = stream_context_create($options);
       $result = @file_get_contents($this->url.$this->apiKey."/ai", false, $context);
       $result = json_decode($result,true);
       $this->ai = array();
       foreach($result["ai"] as $key => $value){
         $this->ai[$key]=$value;
       }
       $this->setAI($result["ai"]);
     }

   }
 }


?>
