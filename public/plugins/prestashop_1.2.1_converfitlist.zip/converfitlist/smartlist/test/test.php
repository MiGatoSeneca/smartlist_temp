<?php
  require "../smartlist.php";

  $smartlist = new SmartList();

  $product = array(
    "IID" => "HELLOSKU",
    "properties" => array(
      "color" => "blue",
      "sizes" => ["32","34"]
    )
  );
  $smartlist->createEvent("view",$product);


  $products = array();

  $products[] = array(
    "IID" => "HELLOSKU1",
    "properties" => array(
      "color" => "blue",
      "sizes" => ["32","34"]
    )
  );

  $products[] = array(
    "IID" => "HELLOSKU2",
    "properties" => array(
      "color" => "blue",
      "sizes" => ["34","36"]
    )
  );

  $products[] = array(
    "IID" => "HELLOSKU3",
    "properties" => array(
      "color" => "red",
      "sizes" => ["32","34"]
    )
  );

  foreach($products as $key => $product){
    error_log($product["IID"]);
  }

  $products = $smartlist->sort($products);

  foreach($products as $key => $product){
    error_log($product["IID"]);
  }


  echo "<pre>";
  echo("\n");
  echo("███████████████████████████████████████████████████████████████████████████╗\n");
  echo("╚══════════════════════════════════════════════════════════════════════════╝\n");
  echo("  ███████╗███╗   ███╗ █████╗ ██████╗ ████████╗██╗     ██╗███████╗████████╗  \n");
  echo("  ██╔════╝████╗ ████║██╔══██╗██╔══██╗╚══██╔══╝██║     ██║██╔════╝╚══██╔══╝  \n");
  echo("  ███████╗██╔████╔██║███████║██████╔╝   ██║   ██║     ██║███████╗   ██║     \n");
  echo("  ╚════██║██║╚██╔╝██║██╔══██║██╔══██╗   ██║   ██║     ██║╚════██║   ██║     \n");
  echo("  ███████║██║ ╚═╝ ██║██║  ██║██║  ██║   ██║   ███████╗██║███████║   ██║     \n");
  echo("  ╚══════╝╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝╚══════╝   ╚═╝     \n");
  echo("                                                                            \n");
  echo("███████████████████████████████████████████████████████████████████████████╗\n");
  echo("╚══════════════════════════════════════════════════════════════════════════╝\n");
  echo("                                                                            \n");

  if(!file_exists("../smartlist.php")){
    echo(" We can't find the smartlist.php file [ERRROR]\n");
    die();
  }
  echo(" Import [OK]\n");
  echo(" Current version @ ".$smartlist->getVersion());
  echo("\n");
  echo(" Start testing\n");
  echo("\n");
  echo("████████████████████████████████████████\n");
  echo(" Check Save ai\n");
  echo(" Save\n");
  echo("\n");
  echo(" Save [ok]\n");
  echo("-----\n");
  echo(" Get\n");
  echo(" Get [ok]\n");
  echo("\n");
  echo("████████████████████████████████████████\n");
  echo(" Check Event sender\n");


  echo("████████████████████████████████████████\n");


  echo "Done!";
?>
